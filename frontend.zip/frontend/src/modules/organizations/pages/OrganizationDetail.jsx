import React from 'react'

const OrganizationDetail = () => {
  return (
    <div>OrganizationDetail</div>
  )
}

export default OrganizationDetail