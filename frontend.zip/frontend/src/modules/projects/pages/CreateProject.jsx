import React from 'react'

const CreateProject = () => {
  return (
    <div>CreateProject</div>
  )
}

export default CreateProject