import React from 'react'

const ProjectDetail = () => {
  return (
    <div>ProjectDetail</div>
  )
}

export default ProjectDetail