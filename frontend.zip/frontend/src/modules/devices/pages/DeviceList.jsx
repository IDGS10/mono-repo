import React from 'react'

const DeviceList = () => {
  return (
    <div>DeviceList</div>
  )
}

export default DeviceList