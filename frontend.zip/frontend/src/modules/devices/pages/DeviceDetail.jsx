import React from 'react'

const DeviceDetail = () => {
  return (
    <div>DeviceDetail</div>
  )
}

export default DeviceDetail