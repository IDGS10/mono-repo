import React from 'react'

const Nodes = () => {
  return (
    <div>Nodes</div>
  )
}

export default Nodes