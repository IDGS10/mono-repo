import React from 'react'

const Monitoring = () => {
  return (
    <div>Monitoring</div>
  )
}

export default Monitoring