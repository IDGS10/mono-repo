import React from 'react'

const Networks = () => {
  return (
    <div>Networks</div>
  )
}

export default Networks