// modules/security/routes/index.js
import { MODULE_CONFIG, ROUTE_DEFINITIONS } from './routeConfig.js';

// Helper para construir rutas completas
const createRoute = (relativePath, config) => ({
  ...config,
  path: MODULE_CONFIG.basePath + (relativePath === '/' ? '' : relativePath)
});

// Procesar definiciones de rutas
const routeDefinitions = ROUTE_DEFINITIONS.map(route => 
  createRoute(route.path, route)
);

// Para React Router
export const securityRoutes = routeDefinitions.map(route => ({
  path: route.path,
  element: <route.component />,
  requiresAuth: route.requiresAuth !== false,
  isPublic: route.isPublic || false,
  name: route.name
}));

// Para el menú (vacío para módulos de sistema)
export const menuConfig = {
  subItems: [] // Los módulos de sistema no aparecen en el menú
};

// Info del módulo
export const moduleInfo = MODULE_CONFIG;

export default securityRoutes;