// modules/analytics/routes/routeConfig.js
import { lazy } from 'react';

// Lazy loading de componentes
const Dashboard = lazy(() => import('../pages/Dashboard.jsx'));
const Reports = lazy(() => import('../pages/Reports.jsx'));

// Configuración del módulo
export const MODULE_CONFIG = {
  basePath: '/analytics',
  name: 'analytics',
  displayName: 'Analytics',
  icon: '📊'
};

// ✨ Configuración fácil de rutas - EL USUARIO SOLO MODIFICA ESTO
export const ROUTE_DEFINITIONS = [
  {
    path: '/',
    component: Dashboard,
    name: 'Dashboard',
    showInMenu: true,
    menuOrder: 1,
    isDefault: true,
    requiresAuth: true,
    permissions: ['analytics.read']
  },
  {
    path: '/dashboard',
    component: Dashboard,
    name: 'Dashboard',
    showInMenu: false, // Alias - no mostrar en menú
    requiresAuth: true
  },
  {
    path: '/reports',
    component: Reports,
    name: 'Reports',
    showInMenu: true,
    menuOrder: 2,
    requiresAuth: true,
    permissions: ['analytics.reports']
  }
];