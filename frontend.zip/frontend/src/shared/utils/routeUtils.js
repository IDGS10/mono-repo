// shared/utils/routeUtils.js - CORREGIDO PARA TODOS LOS MÓDULOS
export const appModuleConfigs = [
  {
    name: 'analytics',
    displayName: 'Analytics',
    icon: '📊',
    path: '/analytics',
    importModule: () => import('../../modules/analytics/routes'),
  },
  {
    name: 'devices',
    displayName: 'Device Manager',
    icon: '📱',
    path: '/devices',
    importModule: () => import('../../modules/devices/routes'),
  },
  {
    name: 'proyects',
    displayName: 'Projects',
    icon: '📋',
    path: '/projects',
    importModule: () => import('../../modules/projects/routes'),
  },
  {
    name: 'organizations',
    displayName: 'Organizations',
    icon: '🏢',
    path: '/organizations',
    importModule: () => import('../../modules/organizations/routes'),
  },
  {
    name: 'swarms',
    displayName: 'Swarm Manager',
    icon: '🐝',
    path: '/swarm',
    importModule: () => import('../../modules/swarms/routes'),
  },
]

export const systemModuleConfigs = [
  {
    name: 'security',
    displayName: 'Security',
    icon: '🔒',
    path: '/auth',
    importModule: () => import('../../modules/security/routes'),
    systemModule: true,
    description: 'Authentication and security management',
  },
]

// Helper para obtener las rutas de un módulo de forma genérica
const getModuleRoutes = (routeModule, moduleName) => {
  // Orden de prioridad para buscar las rutas:
  // 1. Export default
  // 2. Export con nombre del módulo + "Routes" (ej: analyticsRoutes)
  // 3. Export genérico "routes"
  
  if (routeModule.default) {
    return routeModule.default;
  }
  
  // Construir nombre dinámicamente: analytics -> analyticsRoutes
  const moduleRoutesName = `${moduleName}Routes`;
  if (routeModule[moduleRoutesName]) {
    return routeModule[moduleRoutesName];
  }
  
  // Fallback genérico
  if (routeModule.routes) {
    return routeModule.routes;
  }
  
  return null;
};

// Función para cargar rutas de módulos de aplicación
export const loadAppRoutes = async () => {
  const routes = []

  for (const moduleConfig of appModuleConfigs) {
    try {
      const routeModule = await moduleConfig.importModule()
      const moduleRoutes = getModuleRoutes(routeModule, moduleConfig.name);

      if (moduleRoutes) {
        const routesWithMetadata = moduleRoutes.map((route) => ({
          ...route,
          moduleType: 'app',
          moduleName: moduleConfig.name,
          moduleDisplayName: moduleConfig.displayName,
        }))
        routes.push(...routesWithMetadata)
      } else {
        console.warn(`No se encontraron rutas en el módulo ${moduleConfig.name}. 
        Asegúrate de exportar:
        - export default [rutas]
        - export const ${moduleConfig.name}Routes = [rutas]
        - export const routes = [rutas]`);
      }
    } catch (error) {
      console.warn(
        `No se pudieron cargar las rutas del módulo ${moduleConfig.name}:`,
        error
      )
    }
  }

  return routes
}

// Función para cargar rutas de módulos de sistema
export const loadSystemRoutes = async () => {
  const routes = []

  for (const moduleConfig of systemModuleConfigs) {
    try {
      const routeModule = await moduleConfig.importModule()
      const moduleRoutes = getModuleRoutes(routeModule, moduleConfig.name);

      if (moduleRoutes) {
        const routesWithMetadata = moduleRoutes.map((route) => ({
          ...route,
          moduleType: 'system',
          moduleName: moduleConfig.name,
          moduleDisplayName: moduleConfig.displayName,
          requiresAuth: route.requiresAuth !== false,
        }))
        routes.push(...routesWithMetadata)
      } else {
        console.warn(`No se encontraron rutas en el módulo de sistema ${moduleConfig.name}`);
      }
    } catch (error) {
      console.warn(
        `No se pudieron cargar las rutas del módulo de sistema ${moduleConfig.name}:`,
        error
      )
    }
  }

  return routes
}

// Función para cargar todas las rutas (app + system)
export const loadAllRoutes = async () => {
  const [appRoutes, systemRoutes] = await Promise.all([
    loadAppRoutes(),
    loadSystemRoutes(),
  ])

  return [...appRoutes, ...systemRoutes]
}

// Función para cargar solo los elementos del menú
export const loadMenuItems = async () => {
  const menuItems = []

  for (const moduleConfig of appModuleConfigs) {
    try {
      const routeModule = await moduleConfig.importModule()

      // Buscar la configuración del menú en el mismo archivo
      const menuConfig = routeModule.menuConfig

      if (menuConfig) {
        menuItems.push({
          path: moduleConfig.path,
          name: moduleConfig.displayName,
          icon: moduleConfig.icon,
          moduleType: 'app',
          ...menuConfig, // Sobrescribe con la configuración específica
        })
      } else {
        // Configuración por defecto
        menuItems.push({
          path: moduleConfig.path,
          name: moduleConfig.displayName,
          icon: moduleConfig.icon,
          subItems: [],
          moduleType: 'app',
        })
      }
    } catch (error) {
      // Si hay error, usar configuración por defecto
      menuItems.push({
        path: moduleConfig.path,
        name: moduleConfig.displayName,
        icon: moduleConfig.icon,
        subItems: [],
        moduleType: 'app',
      })
      console.warn(`Error cargando menú del módulo ${moduleConfig.name}:`, error)
    }
  }

  return menuItems
}

// Funciones auxiliares (sin cambios)
export const getModuleByPath = (path) => {
  const allModules = [...appModuleConfigs, ...systemModuleConfigs]
  return allModules.find((module) => path.startsWith(module.path))
}

export const isSystemRoute = (path) => {
  return systemModuleConfigs.some((module) => path.startsWith(module.path))
}

export const getPublicRoutes = async () => {
  const systemRoutes = await loadSystemRoutes()
  return systemRoutes.filter((route) => route.requiresAuth === false)
}